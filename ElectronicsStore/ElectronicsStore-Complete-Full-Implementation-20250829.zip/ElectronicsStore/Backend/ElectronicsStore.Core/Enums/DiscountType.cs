namespace ElectronicsStore.Core.Enums
{
    public enum DiscountType
    {
        Percentage = 1,
        FixedAmount = 2
    }
}